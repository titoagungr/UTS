<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Buat Akun');
define('NAVBAR_TITLE_2', 'Sukses');
define('HEADING_TITLE', 'Akan anda telah jadi!');
define('TEXT_ACCOUNT_CREATED', 'Selamat! Akun anda telah jadi! Anda akan mendapatkan keuntungan sebagai anggota untuk kenyamanan belanja Anda bersama kami. Jika <small><strong>ADA</strong></small> pertanyaan sehubungan belanja online, silahkan email ke <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">kami</a>.<br /><br />Konfirmasi telah kami dikirim ke alamat email yang Anda berikan. Jika dalam 1 jam email konfirmasi belum diterima, silahkan <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">hubungi kami</a>.');
?>
