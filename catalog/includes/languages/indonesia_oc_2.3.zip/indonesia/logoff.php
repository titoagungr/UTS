<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Keluar');
define('NAVBAR_TITLE', 'Keluar');
define('TEXT_MAIN', 'Anda telah keluar dari akun Anda. Anda bisa meninggalkan komputer dengan aman.<br /><br />Keranjang belanjaan telah terseimpan, daftar dalam keranjang dapat diakses kembali kapanpun anda login di akun anda.');
?>
