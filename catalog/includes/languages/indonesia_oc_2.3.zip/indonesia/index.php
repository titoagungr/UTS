<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_MAIN', '');
define('TABLE_HEADING_NEW_PRODUCTS', 'Produk Baru %s');
define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Produk yang akan Tersedia');
define('TABLE_HEADING_DATE_EXPECTED', 'Tanggal Tersedia');
define('HEADING_TITLE', 'Selamat Datang di ' . STORE_NAME);
define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Model');
define('TABLE_HEADING_PRODUCTS', 'Nama Produk');
define('TABLE_HEADING_MANUFACTURER', 'Pembuat');
define('TABLE_HEADING_QUANTITY', 'Jumlah');
define('TABLE_HEADING_PRICE', 'Harga');
define('TABLE_HEADING_WEIGHT', 'Berat');
define('TABLE_HEADING_BUY_NOW', 'Beli Sekarang Juga');
define('TEXT_NO_PRODUCTS', 'Produk belum tersedia untuk katogori yang Anda cari.');
define('TEXT_NUMBER_OF_PRODUCTS', 'Jumlah Produk: ');
define('TEXT_SHOW', '<strong>Tampilkan:</strong>');
define('TEXT_BUY', 'Beli 1 \'');
define('TEXT_NOW', '\' sekarang');
define('TEXT_ALL_CATEGORIES', 'Semua Kategori');
define('TEXT_ALL_MANUFACTURERS', 'Semua Pembuat');
?>
