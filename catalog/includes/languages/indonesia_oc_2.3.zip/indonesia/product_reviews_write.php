<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Review');

define('SUB_TITLE_FROM', 'Dari:');
define('SUB_TITLE_REVIEW', 'Rating Anda:');
define('SUB_TITLE_RATING', 'Rating:');

define('TEXT_NO_HTML', '<small><font color="#ff0000"><strong>Catatan:</strong></font></small>&nbsp;HTML tidak diterjemahkan!');
define('TEXT_BAD', '<small><font color="#ff0000"><strong>Baik</strong></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><strong>Buruk</strong></font></small>');

define('TEXT_REVIEW_RECEIVED', 'Terimakasih atas review-nya. Review telah kami kirimkan untuk persetujuan dan akan segera ditampilkan.');

define('TEXT_CLICK_TO_ENLARGE', 'Klik untuk zoom');
?>
