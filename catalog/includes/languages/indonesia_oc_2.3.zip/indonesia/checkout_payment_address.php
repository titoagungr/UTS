<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Selesaikan');
define('NAVBAR_TITLE_2', 'Rubah Alamat Penagihan');

define('HEADING_TITLE', 'Informasi Pembayaran');

define('TABLE_HEADING_PAYMENT_ADDRESS', 'Alamat Penagihan');
define('TEXT_SELECTED_PAYMENT_DESTINATION', 'Ini adalah alamat penagihan yang digunakan sesuai dengan alamat pengiriman.');
define('TITLE_PAYMENT_ADDRESS', 'Alamat penagihan:');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Daftar alamat');
define('TEXT_SELECT_OTHER_PAYMENT_DESTINATION', 'Silahkan pilih alamat penagihan jika akan ditagihkan ke alamat lain.');
define('TITLE_PLEASE_SELECT', 'Silahkan pilih');

define('TABLE_HEADING_NEW_PAYMENT_ADDRESS', 'Alamat penagihan baru');
define('TEXT_CREATE_NEW_PAYMENT_ADDRESS', 'Silahkan gunakan form berikut untuk mengisi alamat penagihan baru/lainnya.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Lanjutkan prosedur selesai belanja online');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'untuk memilih metode pembayaran.');
?>
