<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Pengiriman &amp; Pengembalian');
define('HEADING_TITLE', 'Pengiriman &amp; Pengembalian');

define('TEXT_INFORMATION', 'Barang yang sudah dibeli tidak dapat dikembalikan.');
?>