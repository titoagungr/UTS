<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Security Cek');
define('HEADING_TITLE', 'Security Cek');

define('TEXT_INFORMATION', 'Kami mendeteksi browser anda menggunakan sesi ID SSL menggunakan secure page kami.<br /><br />Untuk keamanan anda harus melakukan login kembali.<br /><br />Konqueror 3.1 tidak mendukung sesi ID SSL otomatis yang dibutuhkan. Jika anda menggunakan browser tersebut, kami rekomendasikan untuk menggunakan browser lain seperti <a href="http://www.google.com/chrome" target="_blank">Google Chrome</a>, <a href="http://www.mozilla.com/" target="_blank">Mozilla Firefox</a>, atau <a href="http://www.opera.com/" target="_blank">Opera</a>, untuk melanjutkan browsing.<br /><br />Kami beruhasa mengamankan Anda, dan maaf untuk ketidaknyamanan ini.<br /><br />Silahkan kontak kami sehubungan dengan dukungan browser anda atau browsing produk kami secara offline.');

define('BOX_INFORMATION_HEADING', 'Privacy dan Security');
define('BOX_INFORMATION', 'Kami melakukan validasi sesi ID SSL yang dibuat secara otoamtis oleh browser anda ssetiap akses ke secure.<br /><br />Validas ini untuk memastikan Anda menggakses site ini dengan menggunakan Akun Anda sendiri dan bukan Akun orang lain.');
?>
