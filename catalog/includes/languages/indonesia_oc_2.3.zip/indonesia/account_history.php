<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Akun Saya');
define('NAVBAR_TITLE_2', 'Riwayat');

define('HEADING_TITLE', 'Riwayat Pemesanan');

define('TEXT_ORDER_NUMBER', 'No Pemesanan:');
define('TEXT_ORDER_STATUS', 'Status Pemesanan:');
define('TEXT_ORDER_DATE', 'Tanggal Pemesanan:');
define('TEXT_ORDER_SHIPPED_TO', 'Dikirim ke:');
define('TEXT_ORDER_BILLED_TO', 'Ditagin ke:');
define('TEXT_ORDER_PRODUCTS', 'Produk:');
define('TEXT_ORDER_COST', 'Biaya Pemesanan:');
define('TEXT_VIEW_ORDER', 'Lihat Pemesanan');

define('TEXT_NO_PURCHASES', 'Anda belum melakukan pembelian apa-apa.');
?>
