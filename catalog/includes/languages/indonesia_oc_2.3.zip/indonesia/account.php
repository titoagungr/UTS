<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Akun Saya');
define('HEADING_TITLE', 'Informasi Akun Saya');

define('OVERVIEW_TITLE', 'Sekilas');
define('OVERVIEW_SHOW_ALL_ORDERS', '(Lihat semua pemesanan)');
define('OVERVIEW_PREVIOUS_ORDERS', 'Pemesanan Sebelumnya');

define('MY_ACCOUNT_TITLE', 'Akun Saya');
define('MY_ACCOUNT_INFORMATION', 'Lihat/Rubah informasi akun Saya.');
define('MY_ACCOUNT_ADDRESS_BOOK', 'Lihat/Rubah alamat Saya.');
define('MY_ACCOUNT_PASSWORD', 'Rubah password akun saya.');

define('MY_ORDERS_TITLE', 'Pesananku');
define('MY_ORDERS_VIEW', 'Lihat pemesanan yang telah saya lakukan.');

define('EMAIL_NOTIFICATIONS_TITLE', 'Email Notifikasi');
define('EMAIL_NOTIFICATIONS_NEWSLETTERS', 'Langganan/berhenti langganan berita.');
define('EMAIL_NOTIFICATIONS_PRODUCTS', 'Lihat/Rubah daftar notifikasi.');
?>