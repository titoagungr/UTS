<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Review');
define('HEADING_TITLE', ' %s Review');
define('SUB_TITLE_PRODUCT', 'Produk:');
define('SUB_TITLE_FROM', 'Dari:');
define('SUB_TITLE_DATE', 'Tanggal:');
define('SUB_TITLE_REVIEW', 'Review:');
define('SUB_TITLE_RATING', 'Rating:');
define('TEXT_OF_5_STARS', '%s dari 5 Bintang!');
define('TEXT_CLICK_TO_ENLARGE', 'Klik untuk zoom');
?>