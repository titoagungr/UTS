<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Keranjang pengunjung / anggota');
define('SUB_HEADING_TITLE_1', 'Keranjang Pengunjung');
define('SUB_HEADING_TITLE_2', 'Keranjang Anggota');
define('SUB_HEADING_TITLE_3', 'Informasi');
define('SUB_HEADING_TEXT_1', 'Setiap pengunjung belanja online akan menggunakan \'Keranjang Pengunjung\'. Ini memungkinkan pengunjung menyimpan daftar belajaannya sementara. Saat pengunjung meninggalkan belanja online daftar belanjaan sementara akah kosong.');
define('SUB_HEADING_TEXT_2', 'Setiap anggota belanja online yang login akan menggunakan \'Keranjang Anggota\'. Ini memungkinkan anggota untuk menimpan daftar belanjaan, dan kebali di lain waktu untuk memproses belanjaannya. Semua produk Semua daftar belanjaan tetap tersimpan di keranjang anggota sampai dibatalkan atau dirubah oleh yang bersangkutan.');
define('SUB_HEADING_TEXT_3', 'Jika anggota menambahkan produk ke  \'Kerangjang Pengunjung\' dan memutuskan untuk login dan menggunakan \'Keranjang Anggota\', daftar belanjaan pada \'Keranjang Pengunjung\' akan dibagungkan/dipindahkan ke \'Keranjang Anggota\' secara otomatis.');
define('TEXT_CLOSE_WINDOW', '[ Tutup ]');
?>