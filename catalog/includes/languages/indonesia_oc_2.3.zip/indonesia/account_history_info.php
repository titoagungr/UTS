<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Akun Saya');
define('NAVBAR_TITLE_2', 'Riwayat');
define('NAVBAR_TITLE_3', 'Pesanan #%s');

define('HEADING_TITLE', 'Informasi Pemesanan');

define('HEADING_ORDER_NUMBER', 'Pemesanan #%s');
define('HEADING_ORDER_DATE', 'Tanggal Pemesanan:');
define('HEADING_ORDER_TOTAL', 'Total Pemesanan:');

define('HEADING_DELIVERY_ADDRESS', 'Alamat Pengiriman');
define('HEADING_SHIPPING_METHOD', 'Metode Pengiriman');

define('HEADING_PRODUCTS', 'Produck');
define('HEADING_TAX', 'Pajak');
define('HEADING_TOTAL', 'Total');

define('HEADING_BILLING_INFORMATION', 'Informasi Tagihan');
define('HEADING_BILLING_ADDRESS', 'Alamat Penagihan');
define('HEADING_PAYMENT_METHOD', 'Metode Pembayaran');

define('HEADING_ORDER_HISTORY', 'Riwayat Pemesanan');
define('HEADING_COMMENT', 'Komentar');
define('TEXT_NO_COMMENTS_AVAILABLE', 'Tidak ada Komentar.');

define('TABLE_HEADING_DOWNLOAD_DATE', 'Link kadaluarsa: ');
define('TABLE_HEADING_DOWNLOAD_COUNT', ' Sisa Download');
define('HEADING_DOWNLOAD', 'link Download');
?>
