<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_PRODUCT_NOT_FOUND', 'Produk tidak ada!');
define('TEXT_CURRENT_REVIEWS', 'Review terbaru:');
define('TEXT_MORE_INFORMATION', 'Untuk informasi lebih lanjut, lihat penjelasan produk ini di <a href="%s" target="_blank"><u>halamannya</u></a>.');
define('TEXT_DATE_ADDED', 'Produk ini ditambahkan dalam katalog pada %s.');
define('TEXT_DATE_AVAILABLE', '<font color="#ff0000">Stok proudk ini akan tersedia pada %s.</font>');
define('TEXT_ALSO_PURCHASED_PRODUCTS', 'Pelanggan yang membeli produk ini juga membeli');
define('TEXT_PRODUCT_OPTIONS', 'Pilihan yang tersedia:');
define('TEXT_CLICK_TO_ENLARGE', 'Klik untuk zoom');
?>
