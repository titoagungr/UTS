<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('EMAIL_TEXT_SUBJECT', 'Proses Pemesanan');
define('EMAIL_TEXT_ORDER_NUMBER', 'Nomor Pesanan:');
define('EMAIL_TEXT_INVOICE_URL', 'Rincian Tagihan:');
define('EMAIL_TEXT_DATE_ORDERED', 'Tanggal Pemesanan:');
define('EMAIL_TEXT_PRODUCTS', 'Produk');
define('EMAIL_TEXT_SUBTOTAL', 'Sub-Total:');
define('EMAIL_TEXT_TAX', 'Pajak:        ');
define('EMAIL_TEXT_SHIPPING', 'Pengiriman/ekspedisi: ');
define('EMAIL_TEXT_TOTAL', 'Total:    ');
define('EMAIL_TEXT_DELIVERY_ADDRESS', 'Alamat Pengiriman');
define('EMAIL_TEXT_BILLING_ADDRESS', 'Alamat Penagihan');
define('EMAIL_TEXT_PAYMENT_METHOD', 'Metode Pembayaran');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('TEXT_EMAIL_VIA', 'melalui');
?>