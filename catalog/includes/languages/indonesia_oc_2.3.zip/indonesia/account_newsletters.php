<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Akun Saya');
define('NAVBAR_TITLE_2', 'Langganan Berita');

define('HEADING_TITLE', 'Langganan Berita');

define('MY_NEWSLETTERS_TITLE', 'Langganan Berita Saya');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Surat Umum');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Termasuk berita Toko, produk baru, penawaran khusus dan promosi lainnya.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Langganan berita telah diperbaharui.');
?>
