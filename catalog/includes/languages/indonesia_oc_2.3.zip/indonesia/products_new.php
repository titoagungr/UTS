<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Produk Baru');
define('HEADING_TITLE', 'Produk Baru');

define('TEXT_DATE_ADDED', 'Ditambahkan tanggal:');
define('TEXT_MANUFACTURER', 'Pembuat:');
define('TEXT_PRICE', 'Harga:');
?>