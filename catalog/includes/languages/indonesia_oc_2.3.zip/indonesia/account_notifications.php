<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Akun Saya');
define('NAVBAR_TITLE_2', 'Berita Produk');

define('HEADING_TITLE', 'Berita Produk');

define('MY_NOTIFICATIONS_TITLE', 'Berita Produk Saya');
define('MY_NOTIFICATIONS_DESCRIPTION', 'Daftar Berita Produk baru yang sesuai minat.<br /><br />Untuk mendapatkan semua berita produk baru dan perubahannya, pilih <strong>Berita Produk Global</strong>.');

define('GLOBAL_NOTIFICATIONS_TITLE', 'Berita Produk Global');
define('GLOBAL_NOTIFICATIONS_DESCRIPTION', 'Terima semua berita tentang semua produk yang tersedia.');

define('NOTIFICATIONS_TITLE', 'Berita Produk');
define('NOTIFICATIONS_DESCRIPTION', 'Untuk berhenti menerima berita produk, kosongkan cekbox dab klik lanjutkan.');
define('NOTIFICATIONS_NON_EXISTING', 'Layanan berita produk belum dipilih.<br /><br />Untuk menambahkan daftar berita produk, klik link Langanan Berita pada halaman deskripsi produk.');

define('SUCCESS_NOTIFICATIONS_UPDATED', 'Layanan berita produk Anda telah diperharui.');
?>
