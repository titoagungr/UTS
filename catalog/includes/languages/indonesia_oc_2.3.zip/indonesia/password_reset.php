<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Login');
define('NAVBAR_TITLE_2', 'Riset Password');

define('HEADING_TITLE', 'Riset Password');

define('TEXT_MAIN', 'Silahkan masukan password baru untuk akun anda.');

define('TEXT_NO_RESET_LINK_FOUND', 'Kesalahan: Link riset password tidak ditemukan dalam catatan kami, silahkan coba untuk membuat link riset baru.');
define('TEXT_NO_EMAIL_ADDRESS_FOUND', 'Kesalahan: Alamat email tidak ditemukan dalam catatan kami, silahkan dicoba kembali.');

define('SUCCESS_PASSWORD_RESET', 'Password anda telah berhasil diperbaharui. Silahkan login dengan menggunakan password baru.');
?>