<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Selesaikan');
define('NAVBAR_TITLE_2', 'Konfirmasi');

define('HEADING_TITLE', 'Konfirmasi Pemesanan');

define('HEADING_SHIPPING_INFORMATION', 'Informasi Pengiriman');
define('HEADING_DELIVERY_ADDRESS', 'Alamat Pengiriman');
define('HEADING_SHIPPING_METHOD', 'Metode Pengiriman');
define('HEADING_PRODUCTS', 'Produk');
define('HEADING_TAX', 'Pajak');
define('HEADING_TOTAL', 'Total');
define('HEADING_BILLING_INFORMATION', 'Informasi Tagihan');
define('HEADING_BILLING_ADDRESS', 'Alamat Penagihan');
define('HEADING_PAYMENT_METHOD', 'Metode/Cara Bayar');
define('HEADING_PAYMENT_INFORMATION', 'Informasi Pembayaran');
define('HEADING_ORDER_COMMENTS', 'Komentar tentang pemesanan Anda');

define('TEXT_EDIT', 'Rubah/Perbaiki');
?>
