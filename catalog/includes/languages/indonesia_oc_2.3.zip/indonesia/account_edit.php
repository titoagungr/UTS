<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Akun Saya');
define('NAVBAR_TITLE_2', 'Rubah Akun');

define('HEADING_TITLE', 'Akun Informasi');

define('MY_ACCOUNT_TITLE', 'Akun Saya');

define('SUCCESS_ACCOUNT_UPDATED', 'Akun Anda telah di perbaharui.');
?>
