<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Akun Saya');
define('NAVBAR_TITLE_2', 'Rubah Password');

define('HEADING_TITLE', 'Password Saya');

define('MY_PASSWORD_TITLE', 'Password Saya');

define('SUCCESS_PASSWORD_UPDATED', 'Password Anda telah diperbaharui.');
define('ERROR_CURRENT_PASSWORD_NOT_MATCHING', 'Password Anda saat ini tidak benar. Silahkan coba lagi.');
?>
