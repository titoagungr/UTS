<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Selesai');
define('NAVBAR_TITLE_2', 'Metode Pengiriman');

define('HEADING_TITLE', 'Informasi Pengiriman');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Alamat Pengiriman');
define('TEXT_CHOOSE_SHIPPING_DESTINATION', 'Silahkan pilih alamat pengiriman pesanan dari daftar alamat Anda.');
define('TITLE_SHIPPING_ADDRESS', 'Alamat Pengiriman:');

define('TABLE_HEADING_SHIPPING_METHOD', 'Metoda Pengiriman');
define('TEXT_CHOOSE_SHIPPING_METHOD', 'Silahkan pilih metode pengiriman pesanan Anda.');
define('TITLE_PLEASE_SELECT', 'Silahkan Pilih');
define('TEXT_ENTER_SHIPPING_INFORMATION', 'Metode pengiriman yang tersedia untuk pemsanan Anda.');

define('TABLE_HEADING_COMMENTS', 'Beri komentar tentang pesanan Anda');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Lanjutkan prosedur pembayaran');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'untuk memilih metode pembayaran pesanan Anda.');
?>
