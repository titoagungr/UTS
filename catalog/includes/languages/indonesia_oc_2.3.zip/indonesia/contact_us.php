<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Hubungi Kami');
define('NAVBAR_TITLE', 'Hubungi Kami');
define('TEXT_SUCCESS', 'Keluhan/Saran Anda telah berhasil terkirim ke Kami.');
define('EMAIL_SUBJECT', 'Keluhan/Saran dari ' . STORE_NAME);

define('ENTRY_NAME', 'Nama Lengkap:');
define('ENTRY_EMAIL', 'Alamat Email:');
define('ENTRY_ENQUIRY', 'Keluhan/Saran:');

define('ERROR_ACTION_RECORDER', 'Error: Keluhan/Saran telah terkirim. Silahakan kirim kembali setelah %s menit.');
?>