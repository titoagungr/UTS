<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_ADMIN_LOGIN_TITLE', 'Login Administration Tool');
  define('MODULE_ACTION_RECORDER_ADMIN_LOGIN_DESCRIPTION', 'Riwayat login Administration Tool.');
?>
