<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_FACEBOOK_TITLE', 'Facebook');
  define('MODULE_SOCIAL_BOOKMARKS_FACEBOOK_DESCRIPTION', 'Berbagi informasi produk di Facebook.');
  define('MODULE_SOCIAL_BOOKMARKS_FACEBOOK_PUBLIC_TITLE', 'Berbagi di Facebook');
?>
