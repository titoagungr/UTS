<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_TITLE', 'Email');
  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_DESCRIPTION', 'Berbagi informasi produk melalui email.');
  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_PUBLIC_TITLE', 'Berbagi melalui email');
?>
