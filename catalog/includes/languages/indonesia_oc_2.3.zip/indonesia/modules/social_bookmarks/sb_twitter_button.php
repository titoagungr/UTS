<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_TWITTER_BUTTON_TITLE', 'Twitter Button');
  define('MODULE_SOCIAL_BOOKMARKS_TWITTER_BUTTON_DESCRIPTION', 'Berbagi informasi produk melalui Twitter Button.');
  define('MODULE_SOCIAL_BOOKMARKS_TWITTER_BUTTON_PUBLIC_TITLE', 'Tweet');
?>
