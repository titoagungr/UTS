<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_ROBOT_NOINDEX_TITLE', 'Robot Tanpa Index');
  define('MODULE_HEADER_TAGS_ROBOT_NOINDEX_DESCRIPTION', 'Tambahkan robot tag noindex pada alamat yang ditentukan');
?>
