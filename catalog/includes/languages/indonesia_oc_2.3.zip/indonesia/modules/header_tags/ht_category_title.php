<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_TITLE', 'Nama Kategori');
  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_DESCRIPTION', 'Tambahkan nama kategori saat ini ke judul halaman');
?>
