<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Pengiriman');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Biaya Pengiriman Pesanan');

  define('FREE_SHIPPING_TITLE', 'Bebas Biaya Pengiriman');
  define('FREE_SHIPPING_DESCRIPTION', 'Bebas Biaya Pengiriman untuk pemesanan lebih dari %s');
?>