<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_TABLE_TEXT_TITLE', 'Tabel Rata-Rata');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION', 'Tabel Rata-Rata');
define('MODULE_SHIPPING_TABLE_TEXT_WAY', 'Cara Terbaik');
define('MODULE_SHIPPING_TABLE_TEXT_WEIGHT', 'Berat');
define('MODULE_SHIPPING_TABLE_TEXT_AMOUNT', 'Sejumlah');
?>
