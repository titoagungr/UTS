<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_USPS_TEXT_TITLE', 'Layanan Pos Indonesia');
define('MODULE_SHIPPING_USPS_TEXT_DESCRIPTION', 'Layanan Pos Indonesia<br /><br />Anda dapat mengecek kiriman di http://www.posindonesia.co.id/.');
define('MODULE_SHIPPING_USPS_TEXT_OPT_PP', 'Pos Parsel');
define('MODULE_SHIPPING_USPS_TEXT_OPT_PM', 'Surat Prioritas');
define('MODULE_SHIPPING_USPS_TEXT_OPT_EX', 'Surat Express');
define('MODULE_SHIPPING_USPS_TEXT_ERROR', 'Gagal menghitung biaya Pos.<br />Jika Anda ingin ingin menggunakan Pos Indonesia, silahkan hubungi kami.');
?>
