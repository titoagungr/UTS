<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ZONES_TEXT_TITLE', 'Zona Rata-Rata');
define('MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION', 'Zona Rata-Rata');
define('MODULE_SHIPPING_ZONES_TEXT_WAY', 'Dikirim ke');
define('MODULE_SHIPPING_ZONES_TEXT_UNITS', 'lb');
define('MODULE_SHIPPING_ZONES_INVALID_ZONE', 'Tidak ada cara pengiriman ke negara tujuan');
define('MODULE_SHIPPING_ZONES_UNDEFINED_RATE', 'Biaya kirim tidak bisa ditentukan saat ini');
?>
