<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SPECIALS_TITLE', 'Spesial');
  define('MODULE_BOXES_SPECIALS_DESCRIPTION', 'Lihat produk spesial');
  define('MODULE_BOXES_SPECIALS_BOX_TITLE', 'Spesial');
?>
