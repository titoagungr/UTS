<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_PRODUCT_SOCIAL_BOOKMARKS_TITLE', 'Bookmark Product Social');
  define('MODULE_BOXES_PRODUCT_SOCIAL_BOOKMARKS_DESCRIPTION', 'Lihat social bookmark pada halaman detail produk');
  define('MODULE_BOXES_PRODUCT_SOCIAL_BOOKMARKS_BOX_TITLE', 'Berbagi tentang produk');
?>
