<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_WHATS_NEW_TITLE', 'Yang Baru');
  define('MODULE_BOXES_WHATS_NEW_DESCRIPTION', 'Lihat produk terbaru');
  define('MODULE_BOXES_WHATS_NEW_BOX_TITLE', 'Apa yang terbaru?');
?>
