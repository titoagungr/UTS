<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SEARCH_TITLE', 'Cari');
  define('MODULE_BOXES_SEARCH_DESCRIPTION', 'Lihat area pencarian');
  define('MODULE_BOXES_SEARCH_BOX_TITLE', 'Cari Cepat');
  define('MODULE_BOXES_SEARCH_BOX_TEXT', 'Gunakan kata kunci untuk mencari produk yang anda inginkan.');
  define('MODULE_BOXES_SEARCH_BOX_ADVANCED_SEARCH', 'Pencarian Lanjutan');
?>
