<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CURRENCIES_TITLE', 'Mata Uang');
  define('MODULE_BOXES_CURRENCIES_DESCRIPTION', 'Lihat Mata Uang yang tersedia');
  define('MODULE_BOXES_CURRENCIES_BOX_TITLE', 'Mata Uang');
?>
