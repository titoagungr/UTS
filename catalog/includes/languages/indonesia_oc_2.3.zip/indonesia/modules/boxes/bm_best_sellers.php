<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_BEST_SELLERS_TITLE', 'Terlaris');
  define('MODULE_BOXES_BEST_SELLERS_DESCRIPTION', 'Lihat global dan kategori terlaris');
  define('MODULE_BOXES_BEST_SELLERS_BOX_TITLE', 'Terlaris');
?>
