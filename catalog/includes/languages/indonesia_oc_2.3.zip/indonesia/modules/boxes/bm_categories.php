<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CATEGORIES_TITLE', 'Kategori');
  define('MODULE_BOXES_CATEGORIES_DESCRIPTION', 'Lihat stuktur kategori');
  define('MODULE_BOXES_CATEGORIES_BOX_TITLE', 'Kategori');
?>
