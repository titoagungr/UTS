<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Review');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Lihar review produk');
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Review');
  define('MODULE_BOXES_REVIEWS_BOX_WRITE_REVIEW', 'Tulis review dari produk ini!');
  define('MODULE_BOXES_REVIEWS_BOX_NO_REVIEWS', 'Tidak ada review dari dari produk ini');
  define('MODULE_BOXES_REVIEWS_BOX_TEXT_OF_5_STARS', '%s dari 5 Bintang!');
?>
