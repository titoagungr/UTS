<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_SHOPPING_CART_TITLE', 'Keranjang Belanjaan');
  define('MODULE_BOXES_SHOPPING_CART_DESCRIPTION', 'Daftar isi keranjang belanjaan');
  define('MODULE_BOXES_SHOPPING_CART_BOX_TITLE', 'Daftar Belajaan');
  define('MODULE_BOXES_SHOPPING_CART_BOX_CART_EMPTY', '0 item');
?>
