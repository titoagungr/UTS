<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_TITLE', 'Berita Produk');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_DESCRIPTION', 'Lihat berita produk di halaman deskripsi produk');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_TITLE', 'Berita Produk');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_NOTIFY', 'Beritatahu saya ke <strong>%s</strong>');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_NOTIFY_REMOVE', 'Jangan beritahu saya ke <strong>%s</strong>');
?>
