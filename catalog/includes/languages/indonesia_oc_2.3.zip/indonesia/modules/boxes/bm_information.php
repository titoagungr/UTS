<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', 'Informasi');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Lihat informasi link');
  define('MODULE_BOXES_INFORMATION_BOX_TITLE', 'Informasi');
  define('MODULE_BOXES_INFORMATION_BOX_PRIVACY', 'Catatan Privacy');
  define('MODULE_BOXES_INFORMATION_BOX_CONDITIONS', 'Syarat dan Kondisi');
  define('MODULE_BOXES_INFORMATION_BOX_SHIPPING', 'Pengiriman &amp; Pengembalian');
  define('MODULE_BOXES_INFORMATION_BOX_CONTACT', 'Hubungi Kami');
?>
