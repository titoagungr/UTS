<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_ORDER_HISTORY_TITLE', 'Riwayat Pemesanan');
  define('MODULE_BOXES_ORDER_HISTORY_DESCRIPTION', 'Lihat pemesanan sebelumnya');
  define('MODULE_BOXES_ORDER_HISTORY_BOX_TITLE', 'Riwayat Pemesanan');
?>
