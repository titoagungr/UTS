<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PSIGATE_TEXT_TITLE', 'PSiGate');
  define('MODULE_PAYMENT_PSIGATE_TEXT_DESCRIPTION', 'Informasi Tes Kartu Kredit:<br /><br />CC#: 4111111111111111<br />Kadaluarsa: Any');
  define('MODULE_PAYMENT_PSIGATE_TEXT_CREDIT_CARD_OWNER', 'Pemilik Kartu Kredit:');
  define('MODULE_PAYMENT_PSIGATE_TEXT_CREDIT_CARD_NUMBER', 'Nomor Kartu Kredit:');
  define('MODULE_PAYMENT_PSIGATE_TEXT_CREDIT_CARD_EXPIRES', 'Tanggal Berlaku Kartu Kredit:');
  define('MODULE_PAYMENT_PSIGATE_TEXT_TYPE', 'Tipe:');
  define('MODULE_PAYMENT_PSIGATE_TEXT_JS_CC_NUMBER', '* minimal nomor Kartu Kredit adalah ' . CC_NUMBER_MIN_LENGTH . ' angka.\n');
  define('MODULE_PAYMENT_PSIGATE_TEXT_ERROR_MESSAGE', 'Terdapat kesalahan dalam memproses Kartu Kredit Anda. Silahkan coba kembali.');
  define('MODULE_PAYMENT_PSIGATE_TEXT_ERROR', 'Kartu Kredit gagal!');
?>