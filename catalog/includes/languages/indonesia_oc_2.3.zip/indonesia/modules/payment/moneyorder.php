<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE', 'Pesanan dengan Cek/Uang');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION', 'Buat Pembayaran untuk:&nbsp;' . MODULE_PAYMENT_MONEYORDER_PAYTO . '<br /><br />Kirim Ke:<br />' . nl2br(STORE_NAME_ADDRESS) . '<br /><br />' . 'Pesanan Anda tidak akan kami kirim sampai pembayarannya Kami Terima.');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_EMAIL_FOOTER', "Buat Pembayaran untuk: ". MODULE_PAYMENT_MONEYORDER_PAYTO . "\n\nKirim Ke:\n" . STORE_NAME_ADDRESS . "\n\n" . 'Pesanan Anda akan segera di kirim setelah pembayarannya Kami terima.');
?>
