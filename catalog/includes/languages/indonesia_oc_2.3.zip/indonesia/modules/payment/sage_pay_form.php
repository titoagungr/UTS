<?php
/*
  $Id: $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2009 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_SAGE_PAY_FORM_TEXT_TITLE', 'Formulir Sage Pay');
  define('MODULE_PAYMENT_SAGE_PAY_FORM_TEXT_PUBLIC_TITLE', 'Kartu Kredit dan Bank (diproses menggunakan Sage Pay)');
  define('MODULE_PAYMENT_SAGE_PAY_FORM_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://support.sagepay.com/apply/default.aspx?PartnerID=C74D7B82-E9EB-4FBD-93DB-76F0F551C802&PromotionCode=osc223" target="_blank" style="text-decoration: underline; font-weight: bold;">Kunjungi Sage Pay</a>&nbsp;<a href="javascript:toggleDivBlock(\'sagePayInfo\');">(info)</a><span id="sagePayInfo" style="display: none;"><br /><i>Gunakan link tersebut untuk membuat akun di Sage Pay dan dapatkan bonus dengan mereferensikan teman Anda.</i></span>');
  define('MODULE_PAYMENT_SAGE_PAY_FORM_ERROR_TITLE', 'Timbul masalah saat memproses transaksi Anda');
  define('MODULE_PAYMENT_SAGE_PAY_FORM_ERROR_GENERAL', 'Silhakan coba kembali dan jika tetap gagal, silahkan gunakan metode pembayaran lain.');
?>
