<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_TITLE', 'PayPoint.net SECPay');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_PUBLIC_TITLE', 'Karu Kredit');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_DESCRIPTION', 'Informasi Tes Kartu Kredit:<br /><br />CC#: 4444333322221111<br />Kadaluarsa: Any');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR', 'Kartu Kredit Gagal!');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE', 'Timbul masalah dalam memproses Kartu Kredit Anda. Silahkan coba kembali.');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE_N', 'Transaksi belum di otorisasi. Silahkan coba kartu lain.');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE_C', 'Timbul masalah dalam komunikasi dengan bank, silahkan coba kembali.');
?>
