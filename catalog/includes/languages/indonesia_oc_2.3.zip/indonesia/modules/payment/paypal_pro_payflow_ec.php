<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2009 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_TITLE', 'Website PayPal Payments Pro (Payflow Edition) - Selesaikan Cepat');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_PUBLIC_TITLE', 'PayPal (termasuk Kartu Kredit dan Debit)');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_DESCRIPTION', '<strong>Catatan: PayPal membutuhkan modul Pembayaran Cepat PayPal Pro (Payflow Edition) - Modul pembayaran Direct Payments harus aktif jika modul ini digunakan.</strong><br /><br /><img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.paypal.com/mrb/pal=PS2X9Q773CKG4" target="_blank" style="text-decoration: underline; font-weight: bold;">Kunjungi PayPal</a>&nbsp;<a href="javascript:toggleDivBlock(\'paypalExpressUKInfo\');">(info)</a><span id="paypalExpressUKInfo" style="display: none;"><br /><i>Gunakan link tersebut untuk membuat akun di PayPal dan dapatkan bonus dengan mereferensikan teman Anda.</i></span>');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_BUTTON', 'Selesaikan dengan PayPal');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_COMMENTS', 'Komentar:');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_GENERAL', 'Error: Masalah yang sering terjadi pada transaksi timbul. Silahkan coba kembali.');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_CFG_ERROR', 'Error: Konfigurasi modul pembayaran salah. Silahkan verifikasi login credential.');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_ADDRESS', 'Error: Alamat Pengiriman tidak sesuai. Silahkan coba kembali.');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_DECLINED', 'Error: Transaksi telah ditolak. Silahkan coba kembali.');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_EXPRESS_DISABLED', 'Error: PayPal Express Checkout telah di non aktifkan untuk produk/merchant ini. Silahkan hubungi layanan pelanggan PayPal.');
?>
