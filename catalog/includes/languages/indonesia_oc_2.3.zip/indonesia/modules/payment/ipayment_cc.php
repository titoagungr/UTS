<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_TITLE', 'iPayment (Kartu Kredit)');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_PUBLIC_TITLE', 'Kartu Kredit');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.ipayment.de" target="_blank" style="text-decoration: underline; font-weight: bold;">Kunjungi iPayment</a>');
  define('MODULE_PAYMENT_IPAYMENT_CC_ERROR_HEADING', 'Gagal memproses Kartu Kredit');
  define('MODULE_PAYMENT_IPAYMENT_CC_ERROR_MESSAGE', 'Silahkan cek kembali Kartu Kredit Anda!');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_OWNER', 'Pemilik Kartu Kredit:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_NUMBER', 'Nomor Kartu Kredit:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_EXPIRES', 'Tanggal berlaku Kartu Kredit:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_CHECKNUMBER', 'Checknumber Kartu Kredit:');
?>
