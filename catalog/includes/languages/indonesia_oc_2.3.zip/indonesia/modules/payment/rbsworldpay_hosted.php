<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_RBSWORLDPAY_HOSTED_TEXT_TITLE', 'RBS WorldPay Hosted');
  define('MODULE_PAYMENT_RBSWORLDPAY_HOSTED_TEXT_PUBLIC_TITLE', 'Kartu Kredit');
  define('MODULE_PAYMENT_RBSWORLDPAY_HOSTED_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="http://www.rbsworldpay.com" target="_blank" style="text-decoration: underline; font-weight: bold;">Kunjungi RBS WorldPay</a>');
  define('MODULE_PAYMENT_RBSWORLDPAY_HOSTED_TEXT_WARNING_DEMO_MODE', 'Review: Transaksi dilakukan dalam mode demo.');
  define('MODULE_PAYMENT_RBSWORLDPAY_HOSTED_TEXT_SUCCESSFUL_TRANSACTION', 'Pembayaran transaksi berhasil dilakukan!');
  define('MODULE_PAYMENT_RBSWORLDPAY_HOSTED_TEXT_CONTINUE_BUTTON', 'Klik disini untuk melanjutkan ke %s');
?>
