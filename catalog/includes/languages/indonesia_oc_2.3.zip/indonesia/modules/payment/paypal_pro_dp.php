<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2009 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPAL_PRO_DP_TEXT_TITLE', 'Website PayPal Pro - Pembayaran Langsung');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_TEXT_PUBLIC_TITLE', 'Kartu Kredit atau Debit');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_TEXT_DESCRIPTION', '<strong>Catatan: PayPal memerlukan modul pembayaran Selesaikan Cepat PayPal yang aktif jika modul ini digunakan.</strong><br /><br /><img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.paypal.com/mrb/pal=PS2X9Q773CKG4" target="_blank" style="text-decoration: underline; font-weight: bold;">Kunjungi PayPal</a>&nbsp;<a href="javascript:toggleDivBlock(\'paypalDirectInfo\');">(info)</a><span id="paypalDirectInfo" style="display: none;"><br /><i>Gunakan link tersebut untuk membuat akun di PayPal dan dapatkan bonus dengan mereferensikan teman Anda.</i></span>');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_OWNER', 'Pemilik Kartu:');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_TYPE', 'Tipe Kartu:');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_NUMBER', 'Nomor Kartu:');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_VALID_FROM', 'Tanggal Berlaku Kartu Dari:');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_VALID_FROM_INFO', '(jika tersedia)');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_EXPIRES', 'Tanggal Berlaku Kartu Sampai:');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_CVC', 'Kode Pengaman Kartu (CVV2):');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_ISSUE_NUMBER', 'Nomor Pembuat Kartu:');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_CARD_ISSUE_NUMBER_INFO', '(hanya untuk kartu Maestro dan Solo)');
  define('MODULE_PAYMENT_PAYPAL_PRO_DP_ERROR_ALL_FIELDS_REQUIRED', 'Error: Semua kolom harus terisi.');
?>
