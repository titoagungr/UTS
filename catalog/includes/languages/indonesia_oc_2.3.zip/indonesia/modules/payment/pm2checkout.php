<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_2CHECKOUT_TEXT_TITLE', '2Checkout');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_PUBLIC_TITLE', '2Checkout');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_PUBLIC_DESCRIPTION', 'Kartu Kredit dan Lainnya');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.2checkout.com/2co/signup?affiliate=1255821" target="_blank" style="text-decoration: underline; font-weight: bold;">Kunjungi 2Checkout</a>&nbsp;<a href="javascript:toggleDivBlock(\'pm2checkoutInfo\');">(info)</a><span id="pm2checkoutInfo" style="display: none;"><br /><i>Gunakan link tersebut untuk membuat akun di 2Checkout dan dapatkan bonus dengan mereferensikan teman Anda.</i></span><br /><br />Info Tes Kartu Kredit:<br /><br />CC#: 4111111111111111<br />Kadaluarsa: Any');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_ERROR_MESSAGE', 'Timbul masalah saat memproses Kartu Kredit Anda. Silahkan coba kembali.');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_WARNING_DEMO_MODE', 'Review: Transaksi dilakukan dalam mode demo.');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_WARNING_TRANSACTION_ORDER', 'Review: Total transaksi tidak sesuai dengan total belanja online.');
?>