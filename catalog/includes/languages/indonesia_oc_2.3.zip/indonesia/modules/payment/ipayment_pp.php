<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_TITLE', 'iPayment (Prabayar)');
  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_PUBLIC_TITLE', 'Prabayar (Paysafecard)');
  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.ipayment.de" target="_blank" style="text-decoration: underline; font-weight: bold;">Kunjungi iPayment</a>');
  define('MODULE_PAYMENT_IPAYMENT_PP_ERROR_HEADING', 'Gagal memproses kartu prabayar Anda');
  define('MODULE_PAYMENT_IPAYMENT_PP_ERROR_MESSAGE', 'Silahkan cek kartu prabayar Anda!');
?>
