<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_AUTHORIZENET_CC_SIM_TEXT_TITLE', 'Authorize.net Kartu Kredit SIM');
  define('MODULE_PAYMENT_AUTHORIZENET_CC_SIM_TEXT_PUBLIC_TITLE', 'Kartu Kredit (diproses oleh Authorize.net)');
  define('MODULE_PAYMENT_AUTHORIZENET_CC_SIM_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.authorize.net" target="_blank" style="text-decoration: underline; font-weight: bold;">Kunjungi Authorize.net</a>');
  define('MODULE_PAYMENT_AUTHORIZENET_CC_SIM_ERROR_TITLE', 'Terjadi kegagalan memproses Kartu Kredit Anda');
  define('MODULE_PAYMENT_AUTHORIZENET_CC_SIM_ERROR_VERIFICATION', 'Transaksi menggunakan Kartu Kredit gagal di verifikasi. Silahkan coba kembali dan jika tetap gagal, silahkan gunakan metode pembayaran lain.');
  define('MODULE_PAYMENT_AUTHORIZENET_CC_SIM_ERROR_DECLINED', 'Transaksi dengan Kartu Kredit ini ditotak. Silahkan coba lagi dan jika tetap gagal, silahkan gunakan metode pembayaran lain.');
  define('MODULE_PAYMENT_AUTHORIZENET_CC_SIM_ERROR_GENERAL', 'Silahkan coba kembali dan jika tetap gagal, silahkan gunakan metode pembayaran lain.');
?>
