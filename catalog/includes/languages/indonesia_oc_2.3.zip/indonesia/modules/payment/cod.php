<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_COD_TEXT_TITLE', 'Tunai saat Pengiriman');
  define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION', 'Tunai saat Pengiriman');
?>