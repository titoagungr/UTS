<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Akun Saya');
define('NAVBAR_TITLE_2', 'Daftar Alamat');

define('HEADING_TITLE', 'Daftar Alamat Pribadi');

define('PRIMARY_ADDRESS_TITLE', 'Alamat Utama');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Alamat ini digunakan untuk referensi pengiriman dan penagihan belanja online.<br /><br />Alamat ini juga digunakan untuk perhitungan pajak barang dan jasa/layanan.');

define('ADDRESS_BOOK_TITLE', 'Isi Daftar Alamat');

define('PRIMARY_ADDRESS', '(alamat utama)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><strong>Catatan:</strong></font> Total %s daftar alamat yang diperbolehkan.');
?>
